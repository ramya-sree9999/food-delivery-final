// src/components/MenuPage.js
// import React from 'react';
// import { useParams } from 'react-router-dom';
// import Menu from './Menu';

// function MenuPage({ addItemToCart }) {
//   const { restaurantId } = useParams();

//   return (
//     <Menu addItemToCart={addItemToCart} restaurantId={parseInt(restaurantId, 10)} />
//   );
// }

// export default MenuPage;
